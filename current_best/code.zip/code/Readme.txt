In order to run the program, please specify corresponding data path and do run "412project.py" in terminal.
If you have any question, please contact Yue Liu via ueliu5@illinois.edu.