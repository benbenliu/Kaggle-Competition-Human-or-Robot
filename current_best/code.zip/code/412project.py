import numpy as np
import pandas as pd
from sklearn.tree import DecisionTreeClassifier
import math,random
from scipy import spatial
from sklearn.cross_validation import KFold
from sklearn.feature_selection import SelectKBest
from sklearn.feature_selection import chi2,f_classif

#Read data in feature.csv
total_data = pd.read_csv('/Users/yueliu/Desktop/features.csv',index_col = 0)

#convert categorical data to numeric, then merge them
catVar = total_data.iloc[:,201]
catMat = pd.get_dummies(catVar)
total_data = pd.DataFrame(np.concatenate((total_data,catMat),axis = 1))

#read train and test raw data
raw_train_data = pd.read_csv('/Users/yueliu/Desktop/projects/kaggle_axis/kaggle/train.csv')
raw_test_data = pd.read_csv('/Users/yueliu/Desktop/projects/kaggle_axis/kaggle/test.csv') 

#prepare the train and test data:
train_data = []
train_labels = []
test_data = []

for i in range(len(total_data)):
    if total_data.iloc[i,0] in list(raw_train_data['bidder_id']):
        train_data.append(total_data.iloc[i,:])
        
    if total_data.iloc[i,0] in list(raw_test_data['bidder_id']):
        test_data.append(total_data.iloc[i,:])

#exclude the bidder id
test_data = np.array(test_data)[:,1:]
train_data = np.array(train_data)[:,1:]

#exclude the original categorical feature
test_data_deleted = np.array(np.delete(test_data,200,1),dtype = np.float64)
train_data_deleted = np.array(np.delete(train_data,200,1),dtype = np.float64)

#handle the missing values. For train, find the class means per feature, for test, only
#find the feature mean

def findClassMean(data_prime):
    data = data_prime
    means_0 = np.ones(data.shape[1]-1)
    means_1 = np.ones(data.shape[1]-1)
    counts_0 = np.zeros(data.shape[1]-1)
    counts_1 = np.zeros(data.shape[1]-1)
    
    for i in range(data.shape[0]):
        for j in range(1,data.shape[1]):
            if data[i,0] == 0 and not(np.isnan(data[i,j])):
                means_0[j-1] += data[i,j]
                counts_0[j-1] += 1
            if data[i,0] == 1 and not(np.isnan(data[i,j])):
                means_1[j-1] += data[i,j]
                counts_1[j-1] += 1
    for i in range(len(means_0)):
        means_0[i] = means_0[i]/counts_0[i]
        means_1[i] = means_1[i]/counts_1[i]
                
    for i in range(data.shape[0]):
        for j in range(1,data.shape[1]):
            if data[i,0] == 0 and np.isnan(data[i,j]):
                data[i,j] = means_0[j-1]
            if data[i,0] == 1 and np.isnan(data[i,j]):
                data[i,j] = means_1[j-1]
    return data

def findMean(data_prime):
    data = data_prime
    means = []
    for i in range(1,data.shape[1]):
        means.append(np.nanmean(data[:,i]))
    for i in range(data.shape[0]):
        for j in range(1,data.shape[1]):
            if np.isnan(data[i,j]):
                data[i,j] = means[j-1]
    return data

#assgin mean to missing values
test_data_final = findMean(test_data_deleted)
train_data_final = findClassMean(train_data_deleted)

#get train lables
train_labels = train_data_final[:,0]


#feature selection by anova test, here keep 350 best features, and then transform test data
train_new = SelectKBest(f_classif, k=350).fit_transform(train_data_final[:,1:], train_labels)
datafit = SelectKBest(f_classif, k=350).fit(train_data_final[:,1:],train_labels)
test_new = datafit.transform(test_data_final[:,1:])

#implement algorithms:

#1.Random Forest:
def fitRandomForest(X,y,criterion,max_features,max_depth,random_state,num_classifiers):
    n_obs = X.shape[0]
    
    trees = []
    
    for i in range(num_classifiers):
        #build decision tree and do in sample classificaiton
        classifer = DecisionTreeClassifier(criterion = criterion,max_features = max_features,max_depth = max_depth,random_state = random_state)
        treeFit = classifer.fit(X,y)
        trees.append(treeFit)    
    
    return trees     

def preRandomForest(X,trees,threshold):
    
    predictions = []
#get the prediction from all the classifiers    
    for i in range(len(trees)):
        pred = trees[i].predict(X)
        predictions.append(pred)
    
    result = np.zeros(X.shape[0])
    
    for i in range(len(trees)):
        result += predictions[i]
    final = []
    for i in range(result.shape[0]):
        result[i] = result[i]/len(trees)
        #print result[i]
        if result[i] > threshold:
            result[i] = 1
        else:
            result[i] = 0
    
    return result

#2.Adaboost:

def fitAdboost(X,y,criterion,max_features,max_depth,random_state,num_classifiers):
    n_obs = X.shape[0]
    weights = np.ones(n_obs)/n_obs
    
    alphas = []
    trees = []
    
    for i in range(num_classifiers):
        #build decision tree and do in sample classificaiton
        classifer = DecisionTreeClassifier(criterion = criterion,max_features = max_features,max_depth = max_depth,random_state = random_state)
        treeFit = classifer.fit(X,y,sample_weight= weights)
        prediction = treeFit.predict(X)
        
        #get the in-sample test result:
        rightOrWrong = (prediction != y)
        error_rate = weights.dot(rightOrWrong)
        #update and normalize weights:
        for i in range(n_obs):
            if rightOrWrong[i] == False:
                weights[i] = (weights[i]*error_rate)/(1-error_rate)
        weights = weights/np.sum(weights)
        #compute alpha:
        alpha = math.log((1-error_rate)/error_rate)
        
        trees.append(treeFit)    
        alphas.append(alpha)
    
    return trees, alphas     

def preAdaboost(X,trees,alphas,learning_rate,threshold):

    predictions = []
#get the prediction from all the classifiers    
    for i in range(len(trees)):
        pred = trees[i].predict(X)
        predictions.append(pred)
    
    result = np.zeros(X.shape[0])
    
    for i in range(len(alphas)):
        result += alphas[i]*predictions[i]*(learning_rate**i)
    
    for i in range(result.shape[0]):
        if result[i] > threshold:
            result[i] = 1
        else:
            result[i] = 0
    
    return result

#3.K-nearest Neighbor:  
def fitKNN(train,label):
    tree = spatial.KDTree(train)
    ptToLabel = dict()
    
    for i in range(train.shape[0]):
        ptToLabel[i] = label[i]
    
    return tree,ptToLabel

def predictKNN(test,k,tree,ptToLabel,threshold):
    pred = []
    for i in range(test.shape[0]):
        neighs = tree.query(test[i,:],k)[1]
        votes = []
        
        for i in range(neighs.shape[0]):
            votes.append(ptToLabel[neighs[i]])
        
        if np.sum(votes) > threshold:
            pred.append(1)
        else:
            pred.append(0)
    return pred

#Randomized Cross Validation for Random Forest:
def randomCV(n_iteration,para_list,X):
    np.random.shuffle(X)
    y = X[:,0]
    results = []
    for i in range(n_iteration):
        toUse = []
        for j in range(len(para_list)):    
            toUse.append(random.sample(para_list[j],1)[0])
        kf = KFold(X.shape[0],n_folds=2)
        Accuracy = 0
        for train_index, test_index in kf:
            trees = fitRandomForest(X[train_index,:], y[train_index],criterion = toUse[0],
                           max_features = toUse[1], max_depth =toUse[2],random_state = None,num_classifiers = toUse[3])
            
            result = preRandomForest(X[test_index,:],trees,toUse[4])
            
            if(abs(sum(result) - np.sum(y[test_index])) < 20):
                print sum(result),np.sum(y[test_index])
                print [toUse[0],toUse[1],toUse[2],toUse[3],toUse[4]]
                print "######################################################"
                results.append([toUse[0],toUse[1],toUse[2],toUse[3],toUse[4]])
            ret = np.array(result)
            Accuracy += 1 - np.sum(abs(ret-y[test_index]))/y[test_index].shape[0]
            
        
        print Accuracy/5
        
    return results

#Sample Usage:
n_iteration = 1000
para_list = [['gini','entropy'],[None,'log2','auto'],[None,5,10,15,20],[100,200,300,400,500],[0.02,0.015,0.025,0.03]]

CV = randomCV(n_iteration,para_list,train_data_final)

#Test and write files:
#Random Forest
trees = fitRandomForest(X = train_new, y = train_labels,criterion = 'gini',
                           max_features ="auto", max_depth =25, random_state = None, num_classifiers = 450)
result = preRandomForest(test_new,trees,0.08)
sum(result)

answer = pd.DataFrame(columns = ['bidder_id', 'prediction'])
answer['bidder_id'] = raw_test_data.iloc[:,0]
answer['prediction'] = np.array(result)
answer.to_csv('/Users/yueliu/Desktop/projects/kaggle_axis/kaggle/submission_rf.csv',index = False)

#Adaboost
trees, alphas = fitAdboost(X = train_data_final[:,1:], y = train_labels,criterion = 'entropy',
                           max_features ="auto", max_depth =10, random_state = None, num_classifiers = 6)
result = preAdaboost(test_data_final[:,1:],trees,alphas,1.1,1.2)
answer = pd.DataFrame(columns = ['bidder_id', 'prediction'])
answer['bidder_id'] = raw_test_data.iloc[:,0]
answer['prediction'] = np.array(result)
answer.to_csv('/Users/yueliu/Desktop/projects/kaggle_axis/kaggle/submission_ada.csv',index = False)

#KNN:
tree,ptToLabel = fitKNN(train_data_final,train_labels)
result = predictKNN(test_data_final,33,tree,ptToLabel,2)
sum(result)
answer = pd.DataFrame(columns = ['bidder_id', 'prediction'])
answer['bidder_id'] = raw_test_data.iloc[:,0]
answer['prediction'] = np.array(result)
answer.to_csv('/Users/yueliu/Desktop/projects/kaggle_axis/kaggle/submission.csv',index = False)







